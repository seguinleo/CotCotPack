CotCot is a PVP / Build / Survival resource pack.
Textures are compressed and optimized for toasters.

I highly recommend :
OptiFine - https://www.optifine.net/home
Complementary Shaders - https://www.curseforge.com/minecraft/customization/complementary-shaders