CotCot is a PVP / Build / Survival resource pack.
Textures are compressed and optimized for toasters.

I highly recommend :
Fabric - https://fabricmc.net/
Sodium - https://www.curseforge.com/minecraft/mc-mods/sodium
Phosphor - https://www.curseforge.com/minecraft/mc-mods/phosphor
Lithium - https://www.curseforge.com/minecraft/mc-mods/lithium
Indium - https://www.curseforge.com/minecraft/mc-mods/indium/files
Continuity - https://www.curseforge.com/minecraft/mc-mods/continuity/files
Colormatic - https://www.curseforge.com/minecraft/mc-mods/colormatic
Iris - https://www.curseforge.com/minecraft/mc-mods/irisshaders
Complementary Shaders - https://www.curseforge.com/minecraft/customization/complementary-shaders